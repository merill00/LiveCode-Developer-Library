# LCB_macAVMidiPlayer
LiveCode LCB FFI Wrapper for mac (and theoretically iOS too) AVMIDIPLayer.

Requires macOS 10.9 or higher (probably iOS 8 or higher too)
