# xalib
Livecode library to eXtract from an Array
