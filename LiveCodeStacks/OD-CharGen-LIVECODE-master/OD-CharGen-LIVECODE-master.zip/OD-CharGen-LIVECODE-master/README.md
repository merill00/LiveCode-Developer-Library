# OD-CharGen-LIVECODE
OneDice Character Generator - LiveCode Version

## Description
This is the OneDice RPG -Character Generator, written in RunRev LiveCode.