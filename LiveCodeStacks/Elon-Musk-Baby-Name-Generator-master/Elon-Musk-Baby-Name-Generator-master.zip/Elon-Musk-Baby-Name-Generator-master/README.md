# Elon-Musk-Baby-Name-Generator
A fun project to create a Elon Musk type baby name generator in LiveCode.


Based on the video here: https://www.youtube.com/watch?v=JRL7mOAFOhE

Images sourced from:
http://clipart-library.com/search2/?q=baby%20clip-art#gsc.tab=1&gsc.q=baby%20clip-art&gsc.page=1

AirCraft Data from:
https://en.wikipedia.org/wiki/List_of_aircraft_type_designators

Latin Extended A character set:
https://en.wikipedia.org/wiki/Latin_Extended-A
