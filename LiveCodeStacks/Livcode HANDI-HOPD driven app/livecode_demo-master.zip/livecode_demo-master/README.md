livecode_demo
=============

Minimal demo of Livcode HANDI-HOPD driven app
