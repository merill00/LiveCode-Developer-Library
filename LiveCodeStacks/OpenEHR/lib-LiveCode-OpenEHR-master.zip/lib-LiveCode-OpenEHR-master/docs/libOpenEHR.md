# The LiveCode libEHR Code Library
LiveCode developer tools for libEHR

This Repository is for LiveCode developers wanting to connect with libEHR

It contains three main elements

A LiveCode scriptOnlyStack (a .scriptonlystack file)
