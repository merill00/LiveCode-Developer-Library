# Test OpenEHR
The 'testOpenEHR' stack

A testLibEHR LiveCode stack (a .livecode stack file - but also can be built to a desktop, iOS and Android app)
