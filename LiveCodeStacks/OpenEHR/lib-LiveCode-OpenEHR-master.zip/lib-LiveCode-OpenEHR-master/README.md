# lib-LiveCode-OpenEHR

This Repo contains dev tools for people using LiveCode wishing to connect with libEHR - and is a collaboration between [FreshEHR's Ian McNicoll](https://github.com/freshehr) and Dave Kilroy

It contains three main elements

1. A LiveCode scriptOnlyStack - see the  [libOpenEHR](/docs/libOpenEHR.md) document for more details

2. A testLibEHR LiveCode stack - see the  [testOpenEHR](/docs/testOpenEHR.md) document for more details

3. A makeLibEHR LiveCode stack - see the [makeOpenEHR](/docs/makeOpenEHR.md) document for more details
