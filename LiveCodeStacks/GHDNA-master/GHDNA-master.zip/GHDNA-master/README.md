# GHDNA
The GHDNA text file contains the text of the code for the livecode program. 
It was built as a generic template for a program that could navigate 
heirarchically structured data. Details are included in the Clarifications text file.
