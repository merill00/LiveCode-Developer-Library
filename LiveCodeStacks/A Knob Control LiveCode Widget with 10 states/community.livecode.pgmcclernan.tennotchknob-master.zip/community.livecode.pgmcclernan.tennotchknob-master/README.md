# community.livecode.pgmcclernan.tennotchknob
A Knob Control LiveCode Widget with 10 states
