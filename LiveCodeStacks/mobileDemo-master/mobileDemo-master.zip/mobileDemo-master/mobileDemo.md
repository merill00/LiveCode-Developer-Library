# MobileDemo
**stack "MobileDemo"**
* ID: stack "MobileDemo"
* [stack_MobileDemo_](./mobileDemo_Scripts/stack_MobileDemo_.livecodescript)

**field "Fullscreen Mode" of bkgnd "grpMode" of stack "MobileDemo"**
* ID: field id 1003 of bkgnd id 1025 of stack "MobileDemo"
* [stack_MobileDemo_field_id_1003](./mobileDemo_Scripts/stack_MobileDemo_field_id_1003.livecodescript)

**field "Stack Size" of bkgnd "grpSize" of stack "MobileDemo"**
* ID: field id 1012 of bkgnd id 1026 of stack "MobileDemo"
* [stack_MobileDemo_field_id_1012](./mobileDemo_Scripts/stack_MobileDemo_field_id_1012.livecodescript)

**card "Index" of stack "MobileDemo"**
* ID: card id 1002 of stack "MobileDemo"
* [stack_MobileDemo_card_id_1002](./mobileDemo_Scripts/stack_MobileDemo_card_id_1002.livecodescript)

**button "SizeBehavior" of group "grpBehaviors" of card "Index" of stack "MobileDemo"**
* ID: button id 1022 of group id 1027 of card id 1002 of stack "MobileDemo"
* [stack_MobileDemo_button_id_1022](./mobileDemo_Scripts/stack_MobileDemo_button_id_1022.livecodescript)

**button "ModeBehavior" of group "grpBehaviors" of card "Index" of stack "MobileDemo"**
* ID: button id 1023 of group id 1027 of card id 1002 of stack "MobileDemo"
* [stack_MobileDemo_button_id_1023](./mobileDemo_Scripts/stack_MobileDemo_button_id_1023.livecodescript)

**button "GroupBehavior" of group "grpBehaviors" of card "Index" of stack "MobileDemo"**
* ID: button id 1024 of group id 1027 of card id 1002 of stack "MobileDemo"
* [stack_MobileDemo_button_id_1024](./mobileDemo_Scripts/stack_MobileDemo_button_id_1024.livecodescript)

**card id 1028 of stack "MobileDemo"**
* ID: card id 1028 of stack "MobileDemo"
* [stack_MobileDemo_card_id_1028](./mobileDemo_Scripts/stack_MobileDemo_card_id_1028.livecodescript)

**card id 1036 of stack "MobileDemo"**
* ID: card id 1036 of stack "MobileDemo"
* [stack_MobileDemo_card_id_1036](./mobileDemo_Scripts/stack_MobileDemo_card_id_1036.livecodescript)

**widget "TreeView" of card id 1036 of stack "MobileDemo"**
* ID: widget id 1037 of card id 1036 of stack "MobileDemo"
* Widget Kind: com.livecode.widget.treeview
* [stack_MobileDemo_widget_id_1037](./mobileDemo_Scripts/stack_MobileDemo_widget_id_1037.livecodescript)

