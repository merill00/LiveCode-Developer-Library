# Script Editor Themer (Seth)
## Script Editor Themer (Seth) is  a helper plugin to extend the LiveCode IDE, it allows the creation of custom color themes for the LiveCode script editor.

## April 2020 - Seth is now free under a MIT License

![SETH](http://2108.co.uk/seth/seth-preview.png)



Project home https://2108.co.uk/
