# CRDE - CockroachDB Data Editor

This application is developed with LiveCode 8


![Screenshot](/images/demo.gif)

[Download prebuilt binaries](https://github.com/setvalue/crde/releases/latest)
