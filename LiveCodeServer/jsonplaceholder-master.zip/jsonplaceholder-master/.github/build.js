// Convert to markdown
// use layout to
// create index.html
// create guide.html
