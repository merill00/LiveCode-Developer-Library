# execution_error_dialog Helper

Levure helper that processes execution error messages
