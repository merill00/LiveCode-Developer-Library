# livecode.widget.fivestars
Five-Star rating system LiveCode Builder Widget has 10 states (half-stars).


