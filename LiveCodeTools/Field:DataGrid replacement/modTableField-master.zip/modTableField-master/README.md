modTableField
Bernd's Table Field/DataGrid replacement for LiveCode