# LiteFE
![Screenshot](/images/demo.gif)

LiteFE - SQLite Front End

1. CRUD for SQLite
2. Read & write blob type as image (JPEG, PNG, GIF)
3. Full-text search
4. Column sorting
5. Portable (download & run without installer required) & multi-platform

![Download prebuilt binaries](https://github.com/setvalue/litefe/releases/latest)
