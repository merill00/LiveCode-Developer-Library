# navigator
The amazing small powerful plugin for Livecode that makes you a better, faster developer.

To install Navigator, you have two options:

1. Download this repo.
2. Download the latest release version of Navigator at https://www.dropbox.com/s/kz3zqi4botzglgq/navigator.zip?dl=1

Whichever way you download Navigator, place Navigator.rev, the commands folder, and the plugins folder in the "My Livecode/Plugins" folder.

Navigator documentation is at https://gcanyon.wordpress.com/navigator-documentation/

Documentation on Navigator's convert to behaviors function is at https://gcanyon.wordpress.com/navigator-convert-to-behaviors-details/

Navigator videos are at https://www.youtube.com/watch?v=RkW1QJvgEa0&list=PL6Q9z_3xloyJJ92D-98ZiOB8ySuUW6sZJ


Thanks for Mikey for helping me get up to speed on git and scriptifying stacks.
