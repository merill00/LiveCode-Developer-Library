# animationEngine
animationEngine is an animation library for liveCode

[![Donate](https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=T8FSXQUVTB92N)

What is new in version 6?

animationEngine 6 has been optimized to work with liveCode version 6.7 and higher, including, but without warranty the current developer preview of the liveCode 9 engine (which is by the time of this writing version 9.01). One of the most notably changes is one in licensing. animationEngine is now in the Public Domain!

Licensing terms:
animationEngine is set free into the Public Domain. The Software is provided "as is" with no warranty.

Availability of source code: you will find the latest sources and documentation on Github.

https://github.com/derbrill/animationEngine

Finally, thank you for helping out! If you purchased a license for animationEngine, I really appreciate that! It helped moving the library forward!
