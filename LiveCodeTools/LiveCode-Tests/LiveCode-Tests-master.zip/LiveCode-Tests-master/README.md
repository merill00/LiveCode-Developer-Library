# LiveCode-Tests
A set of tests of LiveCode written using the LiveCode Mini Test framework.
