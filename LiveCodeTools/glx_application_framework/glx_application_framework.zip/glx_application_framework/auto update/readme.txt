A compressed version of glxappUpdater.rev (updater.gz) is the stack that is
placed on the auto update server. When auto updating an application this stack
is used to perform the update of the application.