This software is distributed under the MIT license. The license agreement can be found in the LICENSE.txt file included with the distribution.

Distribution Version: 14

--------------------
-- Home Page

http://www.bluemangolearning.com/revolution/software/libraries/glx-application-framework/

--------------------
-- API Documentation

http://www.bluemangolearning.com/revolution/docs/glxapp_framework/api_docs/Documents/stack_glxapplicationFramework.htm

--------------------
-- Manual

http://http://revolution.screenstepslive.com/spaces/revolution/manuals/glxapp

The manual will get you up and running your first application in no time.

There is also a PDF folder in the distribution titled "GLX Application Framework.pdf". Although 
the API documentation and Manual will be replacing this file it may still be worth reading.

--------------------
-- Google Group

http://groups.google.com/group/glxapp/

This is where you can discuss the framework with others.

--------------------
-- GLX Application Framework Contributors (in alphabetical order)

George Brackett
Trevor DeVore
Rodney Tamblyn