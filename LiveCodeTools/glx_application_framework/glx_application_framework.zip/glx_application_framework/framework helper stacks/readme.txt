This directory contains the latest versions of the GLX Application Framework
stacks. If you use the plugin to create a new GLX aplication then these stacks
are automatically installed in the proper locations. The stacks in this folder
can be used for updating any existing applications.