This folder contains libraries and plugins that you may find useful in your applications.

standard libraries.rev

The substacks of this stack are libraries that you may find useful in your development.


BroadcastHelper.rev

This stack is a plugin and goes in your Revolution plugins folder. When an application that uses the GLX Application Framework is open you can use this plugin to quickly create and manage controls that broadcast and listen for messages.