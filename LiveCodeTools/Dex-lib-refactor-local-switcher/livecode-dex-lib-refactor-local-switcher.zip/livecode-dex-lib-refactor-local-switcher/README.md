# DEX PROOF-OF-CONCEPT

## How to use
Open `aagDexLib.livecodescript` and then choose between `chat demo.livecode` or `knowledge base demo.livecode` and open those stacks. They will communicate with other machines on the same LAN.

## Where Dex store stuff?
On your **home folder** on a folder called `.dex_store`, inside that folder there will be a `secret.json` file with your identity, a `feed.sqlite` file with the feed database and a `dex.log` with a log of what is going on. 