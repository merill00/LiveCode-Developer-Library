## liveCode Hacktoberfest Ideas

### LiveCode IDE

#### Preferences Dialog
* Modernize Interface and appearance
* Move file to user prefs/settings folder
* Make .yml, .json, or some other easy-to-read-and-write format
* Make navigating panes easier

#### Project Browser
* Restore thumbnails
* Improve behavior when modifying groups (see bug x, y, z)

#### Groups
*
*
*

#### Message Box
* Tab in text entry field should auto fill, the way other text editors work, instead of autofilling with right-arrow

