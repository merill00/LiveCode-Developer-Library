# lcbNSSpeech Library
A LiveCode Builder (LCB) library of bindings for Apple's NSSpeech API

https://www.youtube.com/watch?v=qvI8_y4aQPw
