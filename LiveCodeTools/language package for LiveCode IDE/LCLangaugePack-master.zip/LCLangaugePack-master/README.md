# LCLangaugePack
This is a language package for LiveCode IDE

Modify the json file **language.lcconfig** adding your language.

See https://hedgehao.blogspot.it/2015/01/livecode-language-package-multi.html
