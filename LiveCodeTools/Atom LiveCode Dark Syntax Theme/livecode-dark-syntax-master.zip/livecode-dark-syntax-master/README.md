# LiveCode Dark Syntax Theme

An Atom theme for proper syntax highlighting of LiveCode Builder, LiveCode script-only, LiveCode server and revIgniter source code. This theme is meant to be used with the [Atom LiveCode package (language-livecode)](https://atom.io/packages/language-livecode) provided by Peter Brett.

![Screenshot of LiveCode Syntax theme](https://github.com/revig/livecode-dark-syntax/raw/master/livecodeTheme.png "LiveCode syntax highlighting")
