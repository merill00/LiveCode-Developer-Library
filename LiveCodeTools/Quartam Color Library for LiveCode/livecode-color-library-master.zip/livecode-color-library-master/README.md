# livecode-color-library
Quartam Color Library for LiveCode
